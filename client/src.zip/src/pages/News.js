import React from "react";

//Page Components

//Animations

const News = () => {
  return <h1>News</h1>;
};

export default News;
