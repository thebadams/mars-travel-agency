import React from "react";
import BabyYoda from "../components/404PageComponents/BabyYoda";

const NoMatch = () => {
  return (
     <BabyYoda />
  )
};

export default NoMatch;