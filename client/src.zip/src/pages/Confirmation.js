import React from "react";

import Confirm from "../components/ConfirmationComponents/Confirm"




const Confirmation = () => {
  return (
     <Confirm/>
  )
};

export default Confirmation;